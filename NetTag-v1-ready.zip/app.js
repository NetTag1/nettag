const key="nettag_demo_profile";
const form=document.getElementById("signupForm");
const msg=document.getElementById("message");
form.addEventListener("submit",e=>{
 e.preventDefault();
 const profile={name:document.getElementById("name").value.trim(),tag:document.getElementById("tag").value.trim().replace(/^@/,""),email:document.getElementById("email").value.trim()};
 localStorage.setItem(key,JSON.stringify(profile));
 msg.textContent=`Profile created. Your NetTag is @${profile.tag}`;
 form.reset();
});
document.getElementById("signinForm").addEventListener("submit",e=>{
 e.preventDefault();
 const p=JSON.parse(localStorage.getItem(key)||"null");
 const wanted=document.getElementById("loginTag").value.trim().replace(/^@/,"");
 const out=document.getElementById("loginMessage");
 if(p && p.tag.toLowerCase()===wanted.toLowerCase()) out.textContent=`Welcome back, ${p.name}! Your profile is ready.`;
 else out.textContent="No matching local demo profile found. Create one above first.";
});
